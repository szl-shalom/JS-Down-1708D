function Pagation() {

    this.pageCode = 0;
    this.numDom = document.querySelector("#num")
    this.pageNum = +this.numDom.value
    this.FullData = data
    this.data = this.getFullData()
    console.log(this.data)
    this.midData = this.data.slice()
    this.pageLen = Math.ceil(this.midData.length / this.pageNum)
    this.tbody = document.querySelector("tbody")
    this.pagation = document.querySelector(".pagation")
    console.log(this.pageLen)
    this.footer = document.querySelector(".footer")
    this.search = document.querySelector(".search")
    // 初始化
    this.init()
}

Pagation.prototype = {
    constructor: Pagation,
    init: function () {
        console.log(this.pageCode, this.pageNum)
        var data = this.midData.slice(this.pageCode * this.pageNum, this.pageCode * this.pageNum + this.pageNum)

        this.renderContent(data)
        this.renderFooter()
        this.addEvent()
    },
    getFullData() {
        var data = []
        for (var key in this.FullData) {
            data = data.concat(this.FullData[key])
        }
        return data
    },
    renderContent: function (data) {
        this.tbody.innerHTML = data.map(function (item) {
            return `
            <tr>
                <td>
                    <img src="" alt="">
                </td>
                <td>
                    ${item.name}
                </td>
                <td>
                    ${item.price}
                </td>
            </tr>
            `
        }).join("")
    },
    renderFooter: function () {
        var str = ""
        for (var i = 0; i < this.pageLen; i++) {
            str += `<button class="page ${i === 0?"active":""}"}>${i + 1}</button>`
        }
        this.pagation.innerHTML = str;
    },
    addEvent() {
        this.footer.onclick = (e) => {
            var tar = e.target;
            if (tar.classList.contains("page")) {
                this.change(tar.innerHTML - 1)
            }

            if (tar.className === "prev") {
                var index = this.pageCode - 1
                this.change(index)
            }

            if (tar.className === "next") {
                var index = this.pageCode + 1
                this.change(index)
            }


        }
        this.numDom.addEventListener("change", () => {
            this.pageNum = +this.numDom.value
            this.pageLen = Math.ceil(this.data.length / this.pageNum)
            this.init()
        })

        this.search.addEventListener("input", (e) => {
            var val = this.search.value
            if (val) {
                this.midData = this.data.filter(function (item) {
                    return item.name.includes(val)
                })
            } else {
                this.midData = this.data.slice()
            }
            this.pageLen = Math.ceil(this.midData.length / this.pageNum)
            var data = this.midData.slice(this.pageCode * this.pageNum, this.pageCode * this.pageNum + this.pageNum)
            this.renderContent(data)
            this.renderFooter()

        })
    },
    change(index) {
        if (index < 0 || index > this.pageLen - 1) {
            alert("没有改页码")
            return;
        }
        this.pagation.children[this.pageCode].classList.remove("active")
        this.pageCode = index
        this.pagation.children[this.pageCode].classList.add("active")
        var data = this.midData.slice(this.pageCode * this.pageNum, this.pageCode * this.pageNum + this.pageNum)
        this.renderContent(data)
    }
}