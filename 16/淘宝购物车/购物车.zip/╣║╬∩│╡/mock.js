var data = [{
    name: "海蓝之家",
    children: [{
        price: 18,
        count: 1,
        name: "短裤",
    }, {
        price: 188,
        count: 1,
        name: "长裤",
    }]
}, {
    name: "都市丽人",
    children: [{
        price: 200,
        count: 1,
        name: "内衣",
    }, {
        price: 20,
        count: 1,
        name: "外衣",
    }]
}, {
    name: "海蓝之家",
    children: [{
        price: 18,
        count: 1,
        name: "短裤",
    }, {
        price: 188,
        count: 1,
        name: "长裤",
    }]
}, {
    name: "都市丽人",
    children: [{
        price: 200,
        count: 1,
        name: "内衣",
    }, {
        price: 20,
        count: 1,
        name: "外衣",
    }, {
        price: 200,
        count: 1,
        name: "内衣",
    }, {
        price: 20,
        count: 1,
        name: "外衣",
    }]
}]